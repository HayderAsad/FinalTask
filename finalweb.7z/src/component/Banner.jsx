

function Banner (){
    return(
            <div className="banner-container">
                <div className="banner-items">
                    <div className="banner-titel"> 
                        
                        <h1>MAIN TITLE</h1>
                    </div>
                    <a href="#registration">
                    <button  className="btn banner-reg-btn">Sign Up</button>   
                     </a>
                </div>
               

            </div>
    );
}
export default Banner